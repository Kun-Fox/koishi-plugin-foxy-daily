# koishi-plugin-foxy-daily

基于 **LivingMemory** 的 QQ 空间每日动态插件：从记忆生成动态、定时或手动发布、读取评论、自动/手动回复评论，并把「发动态、读评论、回复评论」注册成 ChatLuna 工具与 chatluna-character 的 reply 字段。

它不会修改 `koishi-plugin-chatluna-livingdiary` 或 `koishi-plugin-qzone`；这是一个独立的新插件。

## 为什么不用 livingdiary

`livingdiary` 的每日总结只统计“当天 00:00 到现在”的记忆，错过 0 点后当天就发不出去；计划时间发布失败后也不会自动重试；评论只能在日志里看到，缺少让机器人主动读取和回复评论的工具。

本插件针对这些点做了补充：

- 06:00 前自动取“昨天”的记忆，错过 0 点仍可补发。
- 支持 `foxy.daily.publish 2026-11-03` 手动指定日期区间。
- 发布失败写入状态文件并指数退避重试，重启后继续。
- 发布结果 `unknown` 时先读回自己的动态确认，不直接重发，避免重复动态。
- 评论轮询 + 状态幂等；支持 ChatLuna / Character 工具让模型主动读评论、回复评论。
- 只自动回复机器人自己动态下的评论；白名单用户的动态只读，用于查看/手动处理。

## 依赖

- Koishi `^4.18`
- `koishi-plugin-chatluna`（生成动态、评论回复；可选安装，但启用每日动态时需要）
- `koishi-plugin-chatluna-livingmemory`（读取记忆与人设）
- 一个能提供 QQ 空间 Cookie 的协议端：OneBot 11 / NapCat（`get_cookies`）或 Milky（`.cookies`）
- `qzone-sdk@^0.3.3`（插件依赖，会随 npm 安装）

## 安装

```powershell
npm install koishi-plugin-foxy-daily
```

或在 Koishi 插件市场搜索 `foxy-daily`。安装后在控制台启用，填写 `allowUserIds` 和 `digestModel`。

## 配置

| 配置 | 默认 | 说明 |
| --- | --- | --- |
| `platform` | `auto` | 获取 QQ 空间 Cookie 的协议：`auto` / `onebot` / `milky` |
| `selfId` | 空 | 指定机器人；留空自动选在线机器人 |
| `allowUserIds` | `[]` | 允许使用指令和工具的用户 QQ；**为空时全部拒绝** |
| `watchUserIds` | `[]` | 额外读取动态的白名单 QQ（只读） |
| `stateFile` | `data/foxy-daily/state.json` | 发布/评论幂等状态；相对路径基于 Koishi 数据目录 |
| `enableDailyDigest` | `true` | 开启每日动态 |
| `digestTime` | `23:50` | 每日触发时间，服务器本地时区 |
| `digestMemoryLimit` | `100` | 单次使用的记忆条数上限 |
| `personaPresetId` | `foxy3` | LivingMemory 的 presetId |
| `persona` | 空 | LivingMemory 不可用时的备用人设 |
| `digestModel` | 空 | 生成动态的 ChatLuna 模型，例如 `deepseek/deepseek-flash` |
| `catchUpPreviousDay` | `true` | 06:00 前补发前一天 |
| `enableCommentAutoReply` | `true` | 自动回复自己动态下的新评论 |
| `commentPollIntervalMinutes` | `5` | 评论轮询间隔 |
| `commentMaxAgeHours` | `72` | 只回复这个时间内的评论 |
| `commentMaxRepliesPerRound` | `3` | 每轮最多自动回复条数 |
| `commentMaxAttempts` | `3` | 单条评论最大尝试次数 |
| `autoReplyAllCommenters` | `true` | 关闭后只回复 `allowUserIds` 中的评论者 |
| `monitorPostLimit` | `10` | 每轮检查的最近动态数 |
| `toolEnabled` | `true` | 注册 ChatLuna 工具 |
| `characterToolEnabled` | `true` | 注册 chatluna-character reply 字段 |
| `imageProvider` | `none` | 配图 provider 名称 |
| `maxImages` | `9` | 单条动态最多图片数 |
| `debug` | `false` | 调试日志 |

## 指令

| 指令 | 说明 |
| --- | --- |
| `foxy.daily` | 查看状态、待重试任务、QQ 空间登录态 |
| `foxy.daily.publish [date]` | 手动发布；`date` 为 `YYYY-MM-DD`，留空按当前时间窗口 |
| `foxy.daily.comments [postId]` | 读取自己（及白名单）动态的评论 |
| `foxy.daily.reply <postId> <commentId> <content>` | 手动回复一条评论 |
| `foxy.daily.retry` | 立即重试待发布任务 |

所有指令都要求 `session.userId` 在 `allowUserIds` 中。

## ChatLuna / Character 工具

ChatLuna 原生工具：

- `qzone_publish`：`{ content?, date? }`。`content` 为空时从 LivingMemory 生成。
- `qzone_comments`：`{ post_id? }`。读取评论。
- `qzone_reply`：`{ post_id, comment_id, content }`。回复评论。

chatluna-character 的 reply 字段同名，均为数组；模型填数组，插件执行并渲染 `<qzone_* ... />`。工具授权同样使用 `allowUserIds`。

> 工具只在私聊或授权场景使用；不要把 `allowUserIds` 留空后公开机器人。

## 记忆窗口与幂等

- 每日默认窗口：当天 00:00 到当前时间；06:00 前自动改为前一天。
- 手动 `date` 会取该日 00:00–23:59。
- 只读取 `personaPresetId` 下 `status=active` 的记忆，按 `createdAt` 过滤；不会改 LivingMemory 的向量索引。
- 同一天发布成功后，`published[date]` 阻止重复发布；模型选择跳过时写 `skipped[date]`。
- 发布失败写 `pending`，5 分钟起指数退避，封顶 6 小时；进程重启后继续。
- `unknown` 结果先读自己的最近动态，按正文精确匹配；确认存在则记为已发布，不直接重发。

## 评论

- 自动轮询只处理机器人自己动态下的一级评论（`kind === 'comment'`）。
- 跳过：自己发的评论、已处理/处理中/unknown/skipped、超过 `commentMaxAgeHours` 的评论。
- 每条评论在 `state.comments[postId][commentId]` 记录 `processing / replied / failed / skipped / unknown`，避免重复回复。
- 手动 `foxy.daily.comments` 也会列出 `watchUserIds` 白名单用户的动态评论，但不会自动回复他们的动态。
- 回复内容由 ChatLuna 模型生成；失败最多尝试 `commentMaxAttempts` 次。

## 配图

插件只提供 provider 接口，不内置截图或表情包生成。其他 Koishi 插件可以：

```js
ctx.foxyDaily.registerImageProvider('my-provider', async ({ content, memories, window, config }) => {
  // 返回字符串 URL、Buffer、Uint8Array，或 qzone-sdk 的 { data, name, mimeType }
  return ['https://example.com/image.png']
})
```

然后把 `imageProvider` 配置为 `my-provider`。插件会把 URL 下载为字节、校验格式并交给 `qzone-sdk`；最多 `maxImages` 张。provider 失败只记日志，不阻塞文字动态。

## 与 livingdiary 的差异

| 能力 | livingdiary | foxy-daily |
| --- | --- | --- |
| 只发当天 | 是 | 支持前一天补发、手动日期 |
| 失败重试 | 有限 | 状态文件 + 指数退避 + 重启恢复 |
| 读评论/回复评论工具 | 无 | ChatLuna + Character |
| 自动回复评论 | 无 | 有，幂等 |
| 指定日期发布 | 无 | 有 |
| 配图 | 无/有限 | provider 接口 |

## 限制

- QQ 空间 Cookie 会过期；过期后需要协议端重新登录，插件会尝试重新获取。
- 自动回复只覆盖机器人自己动态下的一级评论，不自动处理楼中楼或别人动态下的评论。
- `qzone-sdk` 的发布结果可能是 `accepted`（已接受未读回），插件按成功记录；若你要求严格读回，可自行改为等待。
- 动态生成质量取决于模型与记忆质量；`digestModel` 建议使用支持 tool calling 的模型。
- 插件使用服务器本地时区计算“今天/昨天”；跨时区部署需自行调整。
- 未在真实 QQ 空间账号上做发布测试（需要有效 Cookie），本次测试覆盖窗口、状态、评论筛选、发布/失败/unknown 路径与工具注册。

## 测试

```powershell
npm test
```

当前 12 个用例通过：窗口计算、记忆过滤、状态持久化、Cookie 解析、评论筛选/幂等、白名单、摘要工具校验、配图归一化、发布成功/失败/unknown。

## License

MIT
